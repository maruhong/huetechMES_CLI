<template>
  <section>
      <v-container fluid>
        <v-layout>
         <v-card> 
            <v-form class="ma-2" > 
              <v-select v-model="s_projectId"  :items="projectIdItems" item-text="projectId"  label="도면번호 선택" multi-line ></v-select> 
            </v-form> 
          </v-card>
        </v-layout>
        <v-layout align-start justify-left >
          <v-flex md2 class="elevation-1 pa-1 ma-1" >
            <v-card-title>
                      공정 전체 목록
            </v-card-title> 
          
              <v-card class="mx-auto" max-width="1000" max-height="800" scrollable >
                <v-data-iterator  >                  
               <!--  <draggable v-model="processCodeAll" :options="{group:'processCode.ID'}" style="min-height:10px"> -->
                   
                      <v-card  v-for="processCode in processCodeAll" :key="processCode.ID" style="min-height:10px">                    
                        <v-card-title >
                         {{processCode.CODENAME}}
                        </v-card-title>                      
                      </v-card>
                  
              <!--    </draggable> -->
                
                </v-data-iterator>
              </v-card>
            </v-flex>

            <v-flex md3 class="elevation-1 pa-1 ma-1" max-width="1000" max-height="800">
               <v-card-title>
                      사용 공정 목록
               </v-card-title>
              <v-card class="mx-auto"  scrollable>
                <v-list two-line  scrollable>                  
                  <draggable v-model="processCodeReal" :options="{group:'processCode.ID'}" style="min-height:10px">
                    <template v-for="processCode in processCodeReal">
                      <v-list-item :key="processCode.ID" style="min-height:10px"> 
                        <v-list-item-action>
                          <v-checkbox :input-value="active" :true-value="processCode.CODENAME" color="deep-purple accent-4" ></v-checkbox>
                        </v-list-item-action>                   
                        <v-list-item-content >
                          <v-list-item-title >{{processCode.ID}} . {{processCode.CODENAME}}</v-list-item-title>
                        </v-list-item-content>
                       <v-btn  color="success"  @click="processRealSave({ID, CODENAME})">설정</v-btn>
                      </v-list-item>
                    </template>
                  </draggable>
                  <v-btn  color="success"  @click="processRealSave({ID, CODENAME})">저장</v-btn>
                  <v-btn  color="primary"  @click="processRealDelete({ID, CODENAME})">삭제</v-btn>
                </v-list>
              </v-card>
            </v-flex>
         <!--   <v-flex md7 class="elevation-1 pa-1 ma-1" max-width="1000" max-height="800" scrollable>
               <v-card-title>
                      도면 상세 정보
               </v-card-title>
             
            <v-row >
              <v-col cols="5" md="20" >       
                <v-select  v-model="customerNameList"  :items="customerListItems"   item-text="customerName"  label="발주업체 선택"  multi-line ></v-select>
                <v-text-field v-model="text" label="도면번호" required ></v-text-field>
                <v-text-field v-model="text" label="모델명" required></v-text-field>
                <v-text-field v-model="text" label="제품명" required></v-text-field>
                <v-select v-model="cavityNameList"  :items="cavityNameListItems" item-text="cavityName" label="캐비티 선택" multi-line ></v-select> 
                <v-select v-model="materialNameList"  :items="materialNameListItems" item-text="materialName"  label="성형재료 선택" multi-line ></v-select> 
                <v-text-field v-model="text" label="수축율" required></v-text-field> 
                             
                <v-select v-model="camNameList"  :items="camNameListItems" item-text="camName"  label="CAM 선택" multi-line ></v-select> 
                <v-select v-model="cadNameList"  :items="cadNameListItems" item-text="cadName"  label="CAD 선택" multi-line ></v-select>
                <v-combobox v-model="select" :items="manager" label="관리담당자 선택"></v-combobox>              
                <v-link multiple label="도면 이미지 파일"></v-link>
                </v-col> 
                <v-col cols="5" md="20"> 
                <v-menu ref="startDateMenu" v-model="startDateMenu" :close-on-content-click="false" :return-value.sync="startDate"
                  transition="scale-transition" offset-y min-width="290px">
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      label="작업 시작일"
                      v-model="startDate" 
                      prepend-icon="<i class='fa fa-calendar-alt prefix'/>"
                      readonly
                      v-on="on"
                      style="width:250px;padding-top:-10px"
                    ></v-text-field>
                    <v-text-field
                      label="작업시작 시각"
                      v-model="startTime" 
                      prepend-icon="<i class='fa fa-calendar-alt prefix'/>"
                      readonly
                      v-on="on"
                      style="width:250px;padding-top:-10px"
                    ></v-text-field>                 
                  </template>
                  <v-date-picker v-model="startDate" no-title scrollable>
                    <div class="flex-grow-1"></div>
                    <v-btn text color="primary" @click="orderDateMenu = false">Cancel</v-btn>
                    <v-btn text color="primary" @click="$refs.orderDateMenu.save(orderDate)">OK</v-btn>
                  </v-date-picker> 
                  <v-time-picker v-model="startTime"  type="month" width="200" class="ml-2">
                    <div class="flex-grow-1"></div>
                    <v-btn text color="primary" @click="startTimeMenu = false">Cancel</v-btn>
                    <v-btn text color="primary" @click="$refs.orderDateMenu.save(startTime)">OK</v-btn>
                  </v-time-picker>                  
                </v-menu>  
                
               <v-menu ref="endDateMenu" v-model="endDateMenu" :close-on-content-click="false" :return-value.sync="endDate"
                  transition="scale-transition" offset-y min-width="290px">
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      label="작업 종료일"
                      v-model="endDate" 
                      prepend-icon="<i class='fa fa-calendar-alt prefix'/>"
                      readonly
                      v-on="on"
                      style="width:250px;padding-top:-10px"
                    ></v-text-field> 
                    <v-text-field
                      label="작업 종료시각"
                      v-model="endTime" 
                      prepend-icon="<i class='fa fa-calendar-alt prefix'/>"
                      readonly
                      v-on="on"
                      style="width:250px;padding-top:-10px"
                    ></v-text-field>               
                  </template>             
                  
                  <v-date-picker v-model="endDate" no-title scrollable>
                    <div class="flex-grow-1"></div>
                    <v-btn text color="primary" @click="endDateMenu = false">Cancel</v-btn>
                    <v-btn text color="primary" @click="$refs.endDateMenu.save(endDate)">OK</v-btn>
                  </v-date-picker> 
                  <v-time-picker v-model="endTime"  type="month" width="200" class="ml-2">
                    <div class="flex-grow-1"></div>
                    <v-btn text color="primary" @click="endTimeMenu = false">Cancel</v-btn>
                    <v-btn text color="primary" @click="$refs.endTimeMenu.save(endTime)">OK</v-btn>
                  </v-time-picker> 
                </v-menu> 
                 
                <v-menu ref="orderDateMenu" v-model="orderDateMenu" :close-on-content-click="false" :return-value.sync="orderDate"
                  transition="scale-transition" offset-y min-width="290px">
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      label="주문일"
                      v-model="orderDate" 
                      prepend-icon="<i class='fa fa-calendar-alt prefix'/>"
                      readonly
                      v-on="on"
                      style="width:250px;padding-top:-10px"
                    ></v-text-field>               
                  </template>
                  <v-date-picker v-model="orderDate" no-title scrollable>
                    <div class="flex-grow-1"></div>
                    <v-btn text color="primary" @click="orderDateMenu = false">Cancel</v-btn>
                    <v-btn text color="primary" @click="$refs.orderDateMenu.save(orderDate)">OK</v-btn>
                  </v-date-picker> 
                </v-menu>  
               <v-menu ref="dueDateMenu" v-model="dueDateMenu" :close-on-content-click="false" :return-value.sync="dueDate"
                  transition="scale-transition" offset-y min-width="290px">
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      label="납기일"
                      v-model="dueDate" 
                      prepend-icon="<i class='fa fa-calendar-alt prefix'/>"
                      readonly
                      v-on="on"
                      style="width:250px;padding-top:-10px"
                    ></v-text-field>               
                  </template>
                  <v-date-picker v-model="dueDate" no-title scrollable>
                    <div class="flex-grow-1"></div>
                    <v-btn text color="primary" @click="dueDateMenu = false">Cancel</v-btn>
                    <v-btn text color="primary" @click="$refs.dueDateMenu.save(dueDate)">OK</v-btn>
                  </v-date-picker> 
                </v-menu>                   
                <v-text-field multiple label="CAM 파일"></v-text-field>
                <v-text-field multiple label="CAD 파일"></v-text-field>
                <v-text-field multiple label="발주서 "></v-text-field>
                <v-text-field multiple label="견적서 "></v-text-field>
                </v-col>
              </v-row>
            </v-flex> -->
       </v-layout>
      </v-container>
    </section>
</template>

<script>
import draggable from "vuedraggable";
// import ProcessCode from "../components/ProcessCode";

export default {
    name: "processCodeReg",
    components: {
        draggable
    },
    computed : function () {

    },
    beforeCreate() {
        let url = this.APIURL + '/api/getProcessCodeAll';
      //  let url1 = this.APIURL + '/api/getProcessCodeByProject';
        // eslint-disable-next-line
        console.log("3. getProcessCodeReg.vue /api/getProcessCodeReg >>>> " + url )
        this.$http.get(url , null, /*, config */)
          .then ( ret => {
            this.processCodeAll = ret.data; 
              // eslint-disable-next-line
            console.log("4. pass getProcessCodeReg.vue !!!! : " + this.processCodeAll)   
          });
        /*  .then (            
            this.$http.get(url1 , null, , config )
            .then ( ret => {
              this.processCodeReal = ret.data; 
                // eslint-disable-next-line
              console.log("5. pass getProcessCodeReg.vue !!!! : " + this.processCodeReal)   
            })
          ); */
      },
    data() {
        return {
        rowCount : 2,
        even : 2,
        odd : 1,
        model : ['processCode'],
        ID:'',
        CODENAME:'',
        s_projectId:'',        
        orderDateMenu:false,
        dueDataMenu:false,
        startDateMenu:false,
        endDateMenu:false,
        
        startTimeMenu:false,
        endTimeMenu:false,
        orderDate:'',
        dueDate:'',
        startDate:'',
        endDate:'',
        startTime:'',
        endTime:'',

        projectIdItems:['test_019239292_001','test_11902923939_002'],
        processCodeAll: [ 
         /*  { ID: '0001',  align: 'left',   sortable: false, CODENAME: 'CAM1' },
           { ID: '0002',  align: 'left',   sortable: false, CODENAME: 'CAM2' },
           { ID: '0003',  align: 'left',   sortable: false, CODENAME: 'CAM3'}, 
           { ID: '0004',  align: 'left',   sortable: false, CODENAME: 'CAM4' },
           { ID: '0005',  align: 'left',   sortable: false, CODENAME: 'CAM5' },
           { ID: '0006',  align: 'left',   sortable: false, CODENAME: 'CAD1' },
           { ID: '0007',  align: 'left',   sortable: false, CODENAME: 'CAD1' },
           { ID: '0008',  align: 'left',   sortable: false, CODENAME: 'CAD2'}, 
           { ID: '0009',  align: 'left',   sortable: false, CODENAME: 'CAD3' },
           { ID: '0010',  align: 'left',   sortable: false, CODENAME: 'CAD4' } */
        ],
        processCodeReal: [
          
        ]
        };
    },
     methods: {
      processRealSave () {
        
        return true
      },
      processAdding () {
       
        return true
      },
      processRealDelete () {
        
        return true
      },
    },
    created () {
      
    },
};
</script>