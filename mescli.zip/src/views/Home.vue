<template>
  <section class ="container" id="intro">    
    <!-- Default Contents -->
     <div class="card-body text-blue text-center mt-5 pt-5" >
       <h1 class ="mb-4">
         <strong> Hue Technology MES System </strong>
       </h1>
       <p>
         <strong> Best & Free guide of responsive MES System.</strong>
      </p>
     </div>  
<!-- Default form contact -->
  </section>
  <!-- Search form -->
</template>

<script>
// @ is an alias to /src
//import Nav from '@/components/Nav.vue'

export default {
   name: 'Home'
  //  created() {
  //    // eslint-disable-next-line
  //   console.log("Home.vue is token Value" + localStorage.getItem("access-token"))
  //   if(localStorage.getItem("access-token") === null ){
  //      this.$router.push("./views/Login");
  //     } 
  //   }
  //  components: {
//    Nav
 // }
}
</script>
