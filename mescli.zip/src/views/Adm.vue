<template>
 <!--   <section class ="container mt-10 pt-5">
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA 
    </section> -->
   <div class="admin">
    <h1>This is an Admin page</h1>
   </div>
</template>

<script>
export default {
    created() {

    },
    data() {
        return {

        }
    },
    methods: {

    }
}
</script>