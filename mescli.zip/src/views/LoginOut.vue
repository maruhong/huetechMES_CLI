<template>
    <section class ="container mt-10 pt-5">
BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
    </section>

</template>

<script>
  export default {
    name: 'DatatablePage',
    components: {
    
    },
    data() {
      return {
        data: {
        }
      }
    }
  }
</script>