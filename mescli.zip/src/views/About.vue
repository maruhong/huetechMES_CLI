<template>
<section class="container">
  <div class="about">
    <h1>This is an about page</h1>
  </div>
  </section>
</template>
