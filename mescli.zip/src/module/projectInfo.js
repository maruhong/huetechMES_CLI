export default {
    namespaced : true,

    state : {
      popItems : [],
      toggleProjectInfoReg : false,
      toggleProjectInfoEdit : false,
      toggleProjectInfoDetail : false,
      

    },
    getters : {

    },
    //mutations
    mutations : {
      SETITEMS(state,payload) {
        state.popItems = payload
      },
      TOGGLEPROJECTINFOREG(state,payload) {
        state.toggleProjectInfoReg = payload
      },
      TOGGLEPROJECTINFOEDIT(state,payload) {
        state.toggleProjectInfoEdit = payload
      },
      TOGGLEPROJECTINFODETAIL(state,payload) {
        state.toggleProjectInfoDetail = payload
      }
      
    },
    actions : {
    }  
}