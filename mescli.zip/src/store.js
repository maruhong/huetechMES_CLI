import Vue from 'vue'
import Vuex from 'vuex'
import loginInfo from './module/loginInfo'
import empInfo from './module/empInfo'
import projectInfo from './module/projectInfo'
//import { state } from 'fs';

Vue.use(Vuex);

export default new Vuex.Store({
  modules : {
    loginInfo,
    empInfo,
    projectInfo
  }
})
